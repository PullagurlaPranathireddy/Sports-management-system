<?php
    include_once("connection1.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" href = "style.css">
    
    
    <style>
        body{
                background-image: url("img_b.jpg");
                opacity: 1;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: cover;
            }

            .topnav{
                
                background-color: burlywood;
            }

            .topnavleft a{
                float: left;
                color:cornsilk;
                text-align:center;
                padding:14px;
                font-size:20px;
            }

            .topnavright a{
                float:right;
                color:cornsilk;
                text-align:center;
                padding:14px;
                font-size:20px;
            }

            .topnav a:hover{
                background-color: rgb(0, 128, 0);
                color: rgb(230, 141, 207);
            }

            .topnav a.active{
                background-color: rgb(182, 182, 12);
                color: rgba(255, 255, 255, 0.315);
            }

            .dropdown {
                float: left;
                overflow: hidden;
                }

                .dropdown .dropbtn {
                font-size: 16px;  
                border: none;
                outline: none;
                color: white;
                padding: 14px 16px;
                background-color: inherit;
                font-family: inherit;
                margin: 0;
                }

                .topnav a:hover, .dropdown:hover .dropbtn {
                background-color: rgb(0, 128, 0)
                }

                .dropdown-content {
                display: none;
                position: absolute;
                background-color: #f9f9f9;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1;
                }

                .dropdown-content a {
                float: none;
                color: black;
                padding: 12px 16px;
                text-decoration: none;
                display: block;
                text-align: left;
                }

                .dropdown-content a:hover {
                background-color: #ddd;
                }

                .dropdown:hover .dropdown-content {
                display: block;
                }

            table, th, td{
                
                width: 100%;
                padding: 15px;
                text-align: left;
                background-color: #7aafece8;
                padding: 20px;
            }
            
            table, th, td {
                border: 2px solid black;
            }

           

            .container h2{
                text-align:center;
            }

                        
               

    </style>
 </head> 
 <body> 
 <div class="container">  
      <table>
        <tr>
            <th>sports_name</th>
            <th>college_name</th>
            <th>sports_location</th>
            <th>sports_date</th>
            <th>1st_prize</th>
            <th>2nd_prize</th>
            <th>3rd_prize</th>
        </tr>
  
    <?php
        if($num > 0):
            while($result = $stmnt->fetch(PDO::FETCH_ASSOC)): ?>
                    <tr>
                        <td><?php echo $result['sports_name'];?></td>
                        <td><?php echo $result['college_name'];?></td>
                        <td><?php echo $result['sports_location'];?></td>
                        <td><?php echo $result['sports_date'];?></td>
                        <td><?php echo $result['first_prize'];?></td>
                        <td><?php echo $result['second_prize'];?></td>
                        <td><?php echo $result['third_prize'];?></td>
                    </tr>
            <?php endwhile ?>
        <?php endif ?>
            
       
        </table>
            </div>
            </body>
      
            </html>