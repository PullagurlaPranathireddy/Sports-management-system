<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="style2.css">
<style>
table, th, td {
    border: 2px solid black;
}
</style>
</head>
<body>
<div class="container">
<div style="position:relative; top:5px; right: 25%">
<?php
include("conn.php");
error_reporting(0);

if (isset($_POST['search'])) {
    $searchName = $_POST['name'];
    $sql = "SELECT * FROM student_info WHERE name LIKE :searchName";
    $stmt = $conn->prepare($sql);
    $stmt->bindValue(':searchName', '%' . $searchName . '%', PDO::PARAM_STR);
    
    if ($stmt->execute()) {
        if ($stmt->rowCount() > 0) {
            echo "<table>
            <tr>
            
            <th>Dp</th>
            <th>Name</th>
            <th>Id</th>
            <th>Email</th>
            <th>Contact</th>
            <th>Gender</th>
            <th>Date Of Birth</th>
            <th>Department</th>
            <th>Year</th>
            <th>Sports</th>
            </tr>";
            
            // output data of each row
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<tr>
                
                <td><img src='./Dp/" . $row["myfile"] . "' height='50px' width='50px'></td>
                <td>" . $row["name"]. "</td>
                <td> " . $row["id"]. "</td>
                <td> " . $row["email"]. "</td>
                <td> " . $row["contact"]. "</td>
                <td> " . $row["gender"]. "</td>
                <td> " . $row["DOB"]. "</td>
                <td> " . $row["department"]. "</td>
                <td> " . $row["year"]. "</td>
                <td> " . $row["sports"]. "</td>
                </tr>";
            }
            echo "</table>";
        } else {
            echo "No matching records found.";
        }
    } else {
        echo "Query execution failed.";
    }
} else {
    echo "No search query submitted.";
}

$conn = null;
?> 
</div>
</div>

<div style="position:relative; top:-40px; left:5%;">
<form action="admin_show.php" method="POST">
    <input type="submit" name="Back" value="Back"  style="width:20%;">
</form>  
</div>    
</body>
</html>
