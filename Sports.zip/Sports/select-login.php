<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="style2.css">
    <title>Select Login</title>
</head>
<body>
    <div class="container">
        <h1>Login as</h1><br>
        <center>
        <form action="" method="post">
            <input type="button" class="button_active" onclick="location.href='user_login.php'" value="User"><br><br>
            <input type="button" class="button_active" onclick="location.href='admin_login.php'" value="Admin"><br>
        </form>
        </center>
    </div>
</body>
</html>