<?php
session_start();
include_once("connection.php");
?>

<!DOCTYPE html>
<html lang="en">
<head> 
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel = "stylesheet" href = "style1.css">
    
    <style>
        body{
                background-image: url("img_b.jpg");
                opacity: 1;
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: cover;
            }

            .topnav{
                background-color: burlywood;
            }

            .topnavleft a{
                float: left;
                color:cornsilk;
                text-align:center;
                padding:14px;
                font-size:20px;
            }

            .topnavright a{
                float:right;
                color:cornsilk;
                text-align:center;
                padding:14px;
                font-size:20px;
            }

            .topnav a:hover{
                background-color: rgb(0, 128, 0);
                color: rgb(230, 141, 207);
            }

            .topnav a.active{
                background-color: rgb(182, 182, 12);
                color: rgba(255, 255, 255, 0.315);
            }

            table, th, td{
                
                width: 100%;
                padding: 15px;
                text-align: left;
                background-color: #7aafece8;
                padding: 20px;
            }
            
            table, th, td {
                border: 2px solid black;
            }

            .container{
                max-width: 100%;
                background-color:rgb(90, 155, 240);
                padding: 34px;
                margin: auto;
                position:absolute;
                left: auto;
                
            }

            .container h2,h1,p{
                text-align:center;
            }

            

    </style>
</head>
<body>
<div class="container">

<h1>Welcome To Jbiet Sports Event</h1>
        <p>Where learning is an intaractive evalutionary process</p>
        <div class="topnav">
            <div class="topnavleft">
                <a class="active" href="user_show.php">Home</a>
                <a href="contact.html">Contact</a>
                <a href="about.html">About</a>
                <a href="sports_events.php">Events</a>
            </div>

            <div class="topnavright" style="float: right;";>
                <a href="#">Welcome <?php echo $_SESSION['name']; ?></a>
                <a href="logout.php"  style="position:absolute; top:150px; right:200px;">Logout</a>
                <!-- <a href="sign-up.php" id="sigh-up">Signup</a> -->
            </div>
        </div>



        <a href="about.html">
            <img src="img.jpg" alt="Jbiet Sports" style="width: 100%;height: 350px;"></a>

        <h2>Personal Details</h2>
        <div style="width:20%";>


        <?php
        
        error_reporting(0);
        if (isset($_SESSION['name'])) {
            $name = $_SESSION['name'];
        }
        
        $sql = "SELECT * FROM student_info WHERE name = :name";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':name', $name, PDO::PARAM_STR);
        $stmt->execute();
        if ($stmt->rowCount() > 0)  {
            echo "<table style='width:80%'>
            <tr>
           
            <th>Dp</th>
            <th>Name</th>
            <th>Id</th>
            <th>Email</th>
            <th>Contact</th>
            <th>Gender</th>
            <th>Date Of Birth</th>
            <th>Department</th>
            <th>Sports</th>
            <th>Year</th>
            <th>Player</th>
            <th colspan=2 align=center>Operations</th>
            </tr>";
            // output data of each row
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<tr>
               
                <td><img src='./Dp/" . $row["myfile"] . "' height='50px' width='50px'></td>
                <td>" . $row["name"]. "</td>
                <td> " . $row["id"]. "</td>
                <td> " . $row["email"]. "</td>
                <td> " . $row["contact"]. "</td>
                <td> " . $row["gender"]. "</td>
                <td> " . $row["DOB"]. "</td>
                <td> " . $row["department"]. "</td>
                <td> " . $row["sports"]. "</td>
                <td> " . $row["year"]. "</td>
                <td> " . $row["player"]. "</td>
                <td><a href = 'user_update.php ? id=$row[id]&nm=$row[name]&rl=$row[id]&em=$row[email]&con=$row[contact]&gn=$row[gender]&db=$row[DOB]&dp=$row[department]&sp=$row[sports]&ye=$row[year]&pl=$row[player]' onclick='returncheckdelete()'>Edit/Update</td>
                <td><a href = 'user_password.php ? id=$row[id]' onclick='returncheckdelete()'>Change Password</td>
                </tr>";
            }
            echo "</table>";
        } else {
            echo "0 results";
        }
        ?>
    </div>
    <h2>Participation Details</h2>

    <?php   
    $sql1 = "SELECT * FROM participation p JOIN student_info s ON p.student_id = s.id WHERE p.student_id = s.id AND s.name = :name";
    $stmt1 = $conn->prepare($sql1);
    $stmt1->bindParam('name', $name, PDO::PARAM_STR);
    $stmt1->execute();
    if ($stmt1->rowCount() > 0) {
        
        echo "<table>
        <tr>
        <th>Participation ID</th>
        <th>Sports Name</th>
        <th>Location</th>
        <th>Date</th>
        <th>Position</th>
        </tr>";
        // output data of each row
        while ($row = $stmt1->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>
            <td>" . $row["id"]. "</td>
            <td> " . $row["sports_name"]. "</td>
            <td> " . $row["location"]. "</td>
            <td> " . $row["date"]. "</td>
            <td> " . $row["position"]. "</td>
            </tr>";
        }
        echo "</table>";
    } 
    else {
        echo "No participation details available";
    }

    $conn = null;
    ?>
   
 
</div>
</body>
</html>

